#ifndef FASTAreadset_BitArrray_H // include guard
#define FASTAreadset_BitArrray_H

#include <iostream>
#include <fstream>
#include <time.h> 
#include <math.h>

//This constant represents size of character array required to store string representing genomic sequence
#define NucleoLineSize 17

using namespace std;

void PrintCurrentTime();
int strcmp(const char* s1, const char* s2);

class FASTAreadset_BitArrray{
	
	private:
		//recording number of duplicate strings
		int collisions;
		
		//no of flipped bits in bit array
		int elementsStored;
	public:
		//file stream variable
		ifstream file;
		
		//file path variable
		char* filePath;
		
		//pointer to bit array
		char* bitArray;
		
		//size of bit array
		unsigned int bitArraySize;
		
		//number of data lines
		int linesRead;
		
		//Default Constructor
		FASTAreadset_BitArrray(){
			linesRead = 0;
			collisions = 0;
			
			bitArraySize = pow(4, 16) / (sizeof(char) * 8);
			bitArray = new char[bitArraySize];
			for(unsigned int i = 0; i < bitArraySize; i++){
				bitArray[i] = 0;
			}
		}
		
		//Custom constructor taking file path argument
		FASTAreadset_BitArrray(char* path){
			filePath = path;
			
			linesRead = 0;
			collisions = 0;
			
			bitArraySize = pow(4, 16) / (sizeof(char) * 8);
			bitArray = new char[bitArraySize];
			for(unsigned int i = 0; i < bitArraySize; i++){
				bitArray[i] = 0;
			}
		}	
		
		//Method to find radix for a given string
		//A = 0
		//C = 1
		//G = 2
		//T = 3
		unsigned int CalculateRadix(char string[]){
			unsigned int value = 0; //return value
			int i = NucleoLineSize - 1; //array index variable
			int pos = 0; //position of current character from right end
			char current; // for storing the character at a specific index in string
			int base = 4; //base = 4, as there are 4 alphabets
			int posValue; //equivalent integer value of a alphabet
			
			while(i > 0){
				current = string[i - 1];
				switch (current){
					case 'A':
						posValue = 0;
						break;
					case 'C':
						posValue = 1;
						break;
					case 'G':
						posValue = 2;
						break;
					case 'T':
						posValue = 3;
						break;
					}
				value += pow(base, pos) * posValue;
				
				pos++;
				i--;
			}
			
			return value;
		}
		
		//Method to read file
		//filePath contains the path to actual file
		//lines contains the number of lines to be read from file
		void ReadFile(char* filePath){
			cout << "Initialization started at: ";
			PrintCurrentTime();
			
			if(file.is_open()){
				file.close();
			}
			
			file.open(filePath);
			
			string line;
			int count = 0;
			char currentLine[NucleoLineSize]; //keeping track of current node
			bool isHeader = true;
			unsigned int radixValue;
			
			while(getline(file, line)){
				if(!isHeader){
					for(int k = 0; k < NucleoLineSize - 1; k++){
		    		 	currentLine[k] = (line.c_str())[k];
					}
		    	    currentLine[NucleoLineSize - 1] = '\0';
		    	    
		    	    radixValue = CalculateRadix(currentLine);
		    	    SetBitArray(radixValue);
		    	    
					linesRead++;
	    		}
	    		isHeader = !isHeader;
			}
			file.close();
			
			//set the number of elements stored in bit array
			elementsStored = linesRead - collisions;
			
			cout << "Initialization ended at: ";
			PrintCurrentTime();
		}
		
		void SetBitArray(unsigned int radix){
			unsigned int numerator = radix / 8; //size of char is 8 bits
			int remainder = (radix % 8);
			
			unsigned int index = numerator + (((remainder == 0) && (radix != 0)) ? -1 : 0);
			int bitPos = (remainder == 0) ? 8 : remainder;
			bitPos = radix == 0 ? 1 : bitPos;
			
			//check if bit already set
			if(!QueryBitArray(index, bitPos)){
				bitArray[index] |= 1 << (bitPos - 1); 
			}
			else{
				collisions++;			
			}			
		}
		
		bool QueryBitArray(unsigned int index, int bitPos){
			
			bool result = false;
			
			//check if bit is set and return true if it is
			char number = bitArray[index];
			if(((number >> (bitPos - 1)) & 1)){
				result = true;
			}		
			
			return result;
		}
		
		void FindUniqueSequences(){
			cout << "total of " << elementsStored << " unique sequence fragments were found \n"; 
		}
		
		void NumberOfQueries(){
			cout << "total of " << linesRead << " sequence fragments were queried \n"; 
		}
		
		void ReArrange(char array[], int size){
			for(int i = 1; i < size; i++){
				array[i - 1] = array[i];
			}
		}
		
		void DisplaySize(){
			cout << "Bit array size in bytes is " << bitArraySize << "\n";
			double bitSize = bitArraySize * 8.0;
			cout << "Bit array size in bits is " << bitSize << "\n";
		}
		
		//Destructor
		~FASTAreadset_BitArrray(){
			DeleteAllocation();
		}
		
		//Method for deleting memory used by arrays
		void DeleteAllocation(){
			cout << "De allocation started at: ";
			PrintCurrentTime();
			
			delete[] bitArray;
						
			cout << "Successfully de-allocated the memory used for storing records at: ";	
			PrintCurrentTime();		
		}
		
};

void PrintCurrentTime(){
			time_t rawtime;
  			time(&rawtime);
  			tm *ltm = localtime(&rawtime);
			
			cout << ltm->tm_hour << ":";
   			cout << ltm->tm_min << ":";
   			cout << ltm->tm_sec << "\n";
		}
		
int strcmp(const char* string1, const char* string2){
    while(*string1 && (*string1==*string2)){
    	string1++;
		string2++;
	}
        
    return *(const unsigned char*)string1-*(const unsigned char*)string2;
}

#endif
