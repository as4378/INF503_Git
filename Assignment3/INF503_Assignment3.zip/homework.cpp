#include "fastaBA.h"
#include "fastaHT.h"

int main(int argc, char* argv[]) {
		
	char* file = argv[1];
	char* genFile = argv[2];
	char* problem = argv[3];
	
	if(problem[0] == 'A'){
		FASTAreadset_BitArrray fb;
		fb.ReadFile(file);
		fb.DisplaySize();
	}
	else if(problem[0] == 'B'){
		FASTAreadset_BitArrray fb;
		fb.ReadFile(file);
		fb.NumberOfQueries();
	}
	else if(problem[0] == 'C'){
		FASTAreadset_BitArrray fb;
		fb.ReadFile(file);
		fb.FindUniqueSequences();
	}
	else if(problem[0] == 'D'){
		FASTAreadset_hash fh(10000);
		fh.ReadFile(file);
		fh.FindCollisions();
	}
	else if(problem[0] == 'E'){
		FASTAreadset_hash fh(100000);
		fh.ReadFile(file);
		fh.FindCollisions();
	}
	else if(problem[0] == 'F'){
		FASTAreadset_hash fh(10000000);
		fh.ReadFile(file);
		fh.FindCollisions();
	}
	else if(problem[0] == 'G'){
		FASTAreadset_hash fh(10000000);
		fh.ReadFile(file);
		fh.ReadGenomeData(genFile);
	}
	else{
		cout << "Invalid option" << "\n";
	}
	return 0;

	return 0;
}
