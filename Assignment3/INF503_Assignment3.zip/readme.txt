Modules needed for the code:

1. fastaBA.h which is the header file containing the class declaration and definition for FASTAreadset_BitArray.

1. fastaHT.h which is the header file containing the class declaration and definition for FASTAreadset_hash.

2. Other external modules are "math.h" for utility functions, "fstream" for reading files
   and "iostream" for reading input and output to console.

3. time.h which is needed for calculating time taken by process to complete execution.

Following commands are needed to execute different parts of the problem use following format:

./homework {filename for dataset} {filename for genome sequence} {part number}

1. For solving question 1 part A use: ./homework hw3_dataset.fa test_genome.fasta A at commandline
2. For solving question 1 part B use: ./homework hw3_dataset.fa test_genome.fasta B at commandline
3. For solving question 1 part C use: ./homework hw3_dataset.fa test_genome.fasta C at commandline
4. For solving question 2 part A use: ./homework hw3_dataset.fa test_genome.fasta D at commandline
5. For solving question 2 part B use: ./homework hw3_dataset.fa test_genome.fasta E at commandline
6. For solving question 2 part C use: ./homework hw3_dataset.fa test_genome.fasta F at commandline
7. For solving question 2 part D use: ./homework hw3_dataset.fa test_genome.fasta G at commandline

