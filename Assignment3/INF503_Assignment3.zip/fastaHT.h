#ifndef FASTAreadset_hash_H // include guard
#define FASTAreadset_hash_H

#include <iostream>
#include <fstream>
#include <time.h> 
#include <math.h>

//This constant represents size of character array required to store string representing genomic sequence
#define NucleoLineSize 17

using namespace std;

struct Node{
	unsigned int radix;
	Node* next;
};

class FASTAreadset_hash{
			
	public:
		//file stream variable
		ifstream file;
		
		//file path variable
		char* filePath;
		
		//number of data lines
		int linesRead;
		
		//recording number of duplicate strings
		int collisions;
		
		//hash table size
		int hashSize;
		
		//pointer to hash table
		Node** hashTable;

		//Custom constructor taking size argument
		FASTAreadset_hash(int size){			
			linesRead = 0;
			collisions = 0;
			hashSize = size;
			
			hashTable = new Node*[hashSize];
			for(int i = 0; i < hashSize; i++){
				hashTable[i] = NULL;
			}
		}	
		
		//Method to find radix for a given string
		//A = 0
		//C = 1
		//G = 2
		//T = 3
		unsigned int CalculateRadix(char string[]){
			unsigned int value = 0; //return value
			int i = NucleoLineSize - 1; //array index variable
			int pos = 0; //position of current character from right end
			char current; // for storing the character at a specific index in string
			int base = 4; //base = 4, as there are 4 alphabets
			int posValue; //equivalent integer value of a alphabet
			
			while(i > 0){
				current = string[i - 1];
				switch (current){
					case 'A':
						posValue = 0;
						break;
					case 'C':
						posValue = 1;
						break;
					case 'G':
						posValue = 2;
						break;
					case 'T':
						posValue = 3;
						break;
					}
				value += pow(base, pos) * posValue;
				
				pos++;
				i--;
			}
			
			return value;
		}
		
		//Method to read file
		//filePath contains the path to actual file
		//lines contains the number of lines to be read from file
		void ReadFile(char* filePath){
			cout << "Initialization started at: ";
			PrintCurrentTime();
			
			if(file.is_open()){
				file.close();
			}
			
			file.open(filePath);
			
			string line;
			int count = 0;
			char currentLine[NucleoLineSize]; //keeping track of current node
			bool isHeader = true;
			unsigned int radixValue;
			
			while(getline(file, line)){
				if(!isHeader){
					for(int k = 0; k < NucleoLineSize - 1; k++){
		    		 	currentLine[k] = (line.c_str())[k];
					}
		    	    currentLine[NucleoLineSize - 1] = '\0';
		    	    
		    	    radixValue = CalculateRadix(currentLine);
		    	    HashInput(radixValue);
		    	    
					linesRead++;
	    		}
	    		isHeader = !isHeader;
			}
			file.close();
			
			cout << "Initialization ended at: ";
			PrintCurrentTime();
		}
		
		//Method to read genome data
		void ReadGenomeData(char* filePath){
			ifstream file;
			file.open(filePath);
			
			cout << "Searching genome data started at:";
			PrintCurrentTime();
			
			char temp[NucleoLineSize - 1];
			char c = '\0';
			int count = 0;
			int records = 0;
			int match = 0;
			unsigned int radix;
			
			//skipping the first line
			while(c != '\n'){
				file.get(c);	
			}
			
  			while (file.get(c)){
  				if(c == 'A' || c == 'C' || c == 'G' || c == 'T' || c == 'N'){
  					temp[count] = c;
  					count++;
  					if(count == (NucleoLineSize - 1)){
  						count = (NucleoLineSize - 2);
  						records++;
  						radix = CalculateRadix(temp);
  						if(QueryHash(radix)){
  							match++;	
						  }
			    	}
					ReArrange(temp, NucleoLineSize - 1);
				}  
			}         
			file.close();
			
			cout << "A total of " << records << " sequence of 16 mers were queried" << "\n";
			cout << "In all " << match << " of 16 mers were found in dataset" << "\n";
			cout << "Search ended at: ";
			PrintCurrentTime();
		}
		
		void FindCollisions(){
			cout << "total of " << collisions << " collisions occured \n"; 
		}
		
		void NumberOfQueries(){
			cout << "total of " << linesRead << " sequence fragments were queried \n"; 
		}
		
		void ReArrange(char array[], int size){
			for(int i = 1; i < size; i++){
				array[i - 1] = array[i];
			}
		}
		
		void HashInput(unsigned int key){
			int index = key % hashSize;
			
			Node* temp = hashTable[index];
			
			Node* entry = new Node;
			entry -> radix = key;
			entry -> next = NULL;
			
			if(temp == NULL){
				hashTable[index] = entry;
			}
			else{
				collisions++;
//				while(temp -> next != NULL){
//					temp = temp -> next;
//				}
				hashTable[index] = entry;
				entry -> next = temp;
//				temp -> next = entry;
			}
		}
		
		bool QueryHash(unsigned int radix){
			int index = radix % hashSize;
			
			Node* temp = hashTable[index];
			
			if(temp == NULL){
				return false;
			}
			else{
				while(temp -> next != NULL){
					if(temp -> radix == radix){
						return true;
					}
					temp = temp -> next;
				}
				return false;
			}
		}
		
		//Method to search genome sequences
		void SearchGenomeSeq(){
			
			cout << "Search for genomic sequences started at: ";
			PrintCurrentTime();
			
			int total = 0;
			
			
			cout << "Search ended at: ";
			PrintCurrentTime();
			
			cout << "Total " << total << " 16 mers sequences match were found" << "\n";
		}
		
		//Destructor
		~FASTAreadset_hash(){
			DeleteAllocation();
		}
		
		//Method for deleting memory used by arrays
		void DeleteAllocation(){
			cout << "De allocation started at: ";
			PrintCurrentTime();
			
			delete[] hashTable;
						
			cout << "Successfully de-allocated the memory used for storing records at: ";	
			PrintCurrentTime();		
		}
		
		void PrintCurrentTime(){
			time_t rawtime;
  			time(&rawtime);
  			tm *ltm = localtime(&rawtime);
			
			cout << ltm->tm_hour << ":";
   			cout << ltm->tm_min << ":";
   			cout << ltm->tm_sec << "\n";
		}
};




#endif
