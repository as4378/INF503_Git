#include "fasta.h"

int main(int argc, char* argv[]) {
	
	string file = argv[1];
	string problem = argv[2];
	
	FASTAreadset fr(file);
	
	if(problem == "A"){
		fr.InitializeMillion();	
	}
	else if(problem == "B"){
		fr.InitializeAll();
	}
	else if(problem == "C"){
		fr.InitializeAll();
		fr.ComputeStatistics();
	}
	else if(problem == "D"){
		fr.InitializeAll();
		//fr.DeleteAllocation();
	}
	else if(problem == "E"){
		fr.InitializeAll();
		fr.SortGenomicSequences();
	}
	else{
		cout << "Invalid option" << "\n";
	}
	
	return 0;
}
