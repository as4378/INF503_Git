#ifndef FASTAREADSET_H // include guard
#define FASTAREADSET_H

#include <iostream>
#include <fstream>
#include <string.h>
#include <time.h> 

//This constant represents size of character array required to store string representing genomic sequence
#define NucleoLineSize 51

//This constant represents size of character array required to store string representing header data
#define DataSetLineSize 42 

//This constant represents number of data set present in header lines
#define NoOfDataSets 14

using namespace std;

class FASTAreadset{
	
	private:
		ifstream file;
		string filePath;
		
		// for storing the lines read so far
		int linesRead;
		
		//pointer to array of char pointer for storing header lines
		char** dataSet;
		
		//pointer to array of char pointer for storing genomic sequences		
		char** nucleoSet;
		
	public:
		//Default Constructor
		FASTAreadset();
		
		//Custom constructor taking file path argument
		FASTAreadset(string filePath);
		
		//Method to read file
		//filePath contains the path to actual file
		//lines contains the number of lines to be read from file
		void ReadFile(string& filePath, int lines){
			linesRead = lines;
			if(file.is_open()){
				file.close();
			}
			file.open(filePath.c_str());
			string line;
			int count = 0;
			while(lines > 0){
				// read the string representing header data
				getline(file, line);
				strcpy(dataSet[count], line.c_str());
								
				//read the string representing genomic sequence
				getline(file, line);
				strcpy(nucleoSet[count], line.c_str());
				
				count++;
				lines--;
				
			}
			file.close();
		}
		
		//This is an overload method that reads n number of lines from file at file path used when using custom constructor
		void ReadFile(int lines){
			ReadFile(filePath, lines);
		}
		
		//Method to print header data set read so far
		void printDataSet(){
			for(int i = 0; i < linesRead; i++){
				cout << dataSet[i] << "\n";
			}	
		}
		
		//Method to print genomic sequences read so far
		void printNucleoSet(){
			for(int i = 0; i < linesRead; i++){
				cout << nucleoSet[i] << "\n";
			}
		}
		
		//Method returning total number of unique sequence fragments in the entire file
		void TotalUniqueSequenceFragments(){
			int total = 0;
			int flag = 1;
			ifstream file;
			string line; //for storing the current read line
			
			file.open(filePath.c_str());
			
			while(getline(file, line)){
				if((flag % 2) == 0){
					total++;
				}
				flag++;
			}
			
			file.close();
			cout << "The total number of unique sequence fragments are: " << total << "\n";				
		}
		
		//Method to check if a particular header data represents unique genomic sequence
		bool IsUniqueDataSet(int index){
			int count = 0;
			int i = 0;
			int flag = 0;
			
			//skipping characters till first underscore as the actual sequence starts after this character
			while(dataSet[index][i] != '_'){
				i++;
			}
			
			i++; //incrementing one more time to fetch the next character after underscore
			
			while(count <= NoOfDataSets){
				count++;
				
				if(dataSet[index][i] == '1'){
					flag++;
				}
				
				if(dataSet[index][i] != '1' && dataSet[index][i] != '0' && dataSet[index][i] != '\n' && dataSet[index][i] != '\t' && dataSet[index][i] != '\0'){
					return false;
				}
				i = i + 2;
			}
			if(flag == 1){
				return true;
			}
			else{
				return false;
			}
		}
		
		//Method to count total number of reads for each data set
		int TotalCountDataSet(){
						
			int dataSetCount[NoOfDataSets];
			for(int x = 0; x < NoOfDataSets; x++){
				dataSetCount[x] = 0;
			}
			
			int count;
			int i;
			int index;
			
			for(index = 0; index < linesRead; index++){
				count = 0;
				i = 0;
				
				//skipping characters till first underscore as the actual sequence starts after this character
				while(dataSet[index][i] != '_'){
					i++;
				}
				
				i++; //incrementing one more time to fetch the next character after underscore
				
				while(count <= NoOfDataSets){
					count++;
					if(dataSet[index][i] >= '0' && dataSet[index][i] <= '9'){
						int value = dataSet[index][i] - '0'; // getting integer value by subtracting char value of '0'
						dataSetCount[count - 1] += value;
					}
					i = i + 2;
				}
			}
			cout << "The number of reads for each data set are as follows:" << "\n"; 
			for(int i = 0; i < NoOfDataSets; i++){
				cout << "DataSet " << i + 1 << ": " << dataSetCount[i] << "\n";
			}
			return 0;
		}
		
		//Method to count A, C, G and T characters in the entire 
		void CountCharacters(){
			int a = 0;
			int c = 0;
			int g = 0;
			int t = 0;
			
			for(int i = 0; i < linesRead; i++){
				for(int j = 0; j < NucleoLineSize; j++){
					if(nucleoSet[i][j] == 'A'){
						a++;
					}
					else if(nucleoSet[i][j] == 'C'){
						c++;
					}
					else if(nucleoSet[i][j] == 'G'){
						g++;
					}
					else if(nucleoSet[i][j] == 'T'){
						t++;
					}
				}
			}
			
			cout << "The total number of characters present in the data set are as follows:" << "\n";
			cout << "A: " << a << "\n";
			cout << "C: " << c << "\n";
			cout << "G: " << g << "\n";
			cout << "T: " << t << "\n";
		}
		
		//Utility function used by quick sort
		void swap(char *v[], int i, int j){
			char* temp;
			temp = v[i];
			v[i] = v[j];
			v[j] = temp;	
		}
		
		//Utility function for sorting strings
		void QuickSort(char* v[], int left, int right){
			int i;
			int last;
			
			if(left >= right){
				return;
			}
			swap(v, left, (left + right)/2);
			last = left;
			
			for(i = left + 1; i <= right; i++){
				if(strcmp(v[i], v[left]) < 0){
					swap(v, ++last, i);
				}
			}
			swap(v, left, last);
			QuickSort(v, left, last - 1);
			QuickSort(v, last + 1, right);
		}
		
		//Method to sort genomic sequences
		void SortGenomicSequences(){
			
			cout << "Sorting started at: ";
			PrintCurrentTime();
						
			char** v = new char*[linesRead];
			
			for(int i = 0; i < linesRead; i++){
				v[i] = nucleoSet[i];
			}
			
			QuickSort(v, 0, linesRead - 1);
			
			//copying the string represented by sorted array to new array
			char** sortedNucleoSet = new char*[linesRead];		
			for(int i = 0; i < linesRead; i++){
				sortedNucleoSet[i] = new char[NucleoLineSize];
				strcpy(sortedNucleoSet[i], v[i]);
			}
			
			cout << "Sorted the dataset at: ";
			PrintCurrentTime();
			
			cout << "First 10 lines after sorting are as follows:" << "\n";
			
			for(int i = 0; i < 10; i++){
				cout << sortedNucleoSet[i] << "\n";
			}
			
			//avoiding memory leakage
			for(int i = 0; i < linesRead; i++){
				delete[] sortedNucleoSet[i];
				delete[] v[i];
			}
			delete[] sortedNucleoSet; // deleting this because we have no further use of sorted array
			delete[] v; 
		}

		//Method to initialize array with first 1 million lines
		void InitializeMillion(){	
			
			cout << "Initialization started at: ";
			PrintCurrentTime();
			
			dataSet = new char*[10000000];
			nucleoSet = new char*[10000000];		
			for(int i = 0; i < 10000000; i++){
				nucleoSet[i] = new char[NucleoLineSize];
				dataSet[i] = new char[DataSetLineSize];
			}
			ReadFile(10000000);
		
			cout << "Successfully initialized with first 10 million reads at: ";
			PrintCurrentTime(); 
		}
		
		//Method to initialize array with all 36 million records 
		void InitializeAll(){
			
			cout << "Initialization started at: ";
			PrintCurrentTime();
			
			dataSet = new char*[36000000];
			nucleoSet = new char*[36000000];		
			for(int i = 0; i < 36000000; i++){
				nucleoSet[i] = new char[NucleoLineSize];
				dataSet[i] = new char[DataSetLineSize];
			}
			ReadFile(36000000);
			
			cout << "Successfully initialized with 36 million reads at: ";
			PrintCurrentTime(); 
		}
		
		//Method for computing statistics
		void ComputeStatistics(){
			TotalUniqueSequenceFragments();
			TotalCountDataSet();
			CountCharacters();
		}
		
		//Destructor
		~FASTAreadset(){
			DeleteAllocation();
		}
		
		void PrintCurrentTime(){
			time_t rawtime;
  			time(&rawtime);
  			tm *ltm = localtime(&rawtime);
			
			cout << ltm->tm_hour << ":";
   			cout << ltm->tm_min << ":";
   			cout << ltm->tm_sec << "\n";
		}
		
		//Method for deleting memory used by arrays
		void DeleteAllocation(){
			cout << "De allocation started at: ";
			PrintCurrentTime();
			
			for(int i = 0; i < linesRead; i++){
				delete[] dataSet[i];
				delete[] nucleoSet[i];
			}
			delete[] dataSet;
			delete[] nucleoSet;
			
			cout << "Successfully de-allocated the memory used for storing records at: ";	
			PrintCurrentTime();		
		}
};

//Custom constructor implementation: setting private variable for file path
FASTAreadset::FASTAreadset(string path){
	filePath = path;
}

//Default constructor implementation: doing nothing
FASTAreadset::FASTAreadset(){
}

#endif
