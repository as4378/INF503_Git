Modules needed for the code:

1. fasta.h which is the header file containing the class declaration and definition for FASTAreadset.
2. Other external modules are "string.h" for utility functions related to string data type, "fstream" for reading files
   and "iostream" for reading input and output to console.
3. time.h which is needed for calculating time taken by process to complete execution.

Following commands are needed to execute different parts of the problem use following format:

./homework {filename} {part number}

1. For solving part A use: ./homework hw_dataset.fa A at commandline arguments
2. For solving part B use: ./homework hw_dataset.fa B at commandline arguments
3. For solving part C use: ./homework hw_dataset.fa C at commandline arguments
4. For solving part D use: ./homework hw_dataset.fa D at commandline arguments
5. For solving part E use: ./homework hw_dataset.fa E at commandline arguments

Note: For part A and part B I have created 2 jobs partA.sh and partB.sh which will be required to run when approximating
      the memory consumed.