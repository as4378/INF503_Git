#!/bin/bash
#SBATCH --job-name=exercise                        # the name of your job
#SBATCH --output=/scratch/as4378/exercise.out	# this is the file your output and errors go to
#SBATCH --time=6:00				# 20 min, shorter time, quicker start, max run time 
#SBATCH --workdir=/home/as4378		# your work directory
#SBATCH --mem=10000                              # 2GB of memory

# load a module, for example


# run your application, precede the application command with srun
# a couple example applications ...

srun ./homework hw_dataset.fa A
