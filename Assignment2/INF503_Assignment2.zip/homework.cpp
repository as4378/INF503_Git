#include "fasta.h"

int main(int argc, char* argv[]) {
	
	char* file = argv[1];
	char* genFile = argv[2];
	char* problem = argv[3];
	
	FASTAreadset_LL fr(file);
	
	if(problem[0] == 'A'){
		fr.InitializeAll();	
	}
	else if(problem[0] == 'B'){
		fr.InitializeAll();
	}
	else if(problem[0] == 'C'){
		fr.InitializeAll();
		fr.ReadGenomeData(genFile);
		
		FASTAreadset_LL fr1(fr);
	}
	else if(problem[0] == 'D'){
		fr.InitializeAll();
		fr.SortGenomicSequences();
		fr.PerformSearch();
	}
	else if(problem[0] == 'E'){
		fr.ReadGenomeData(genFile);
	}
	else if(problem[0] == 'F'){
		fr.InitializeAll();
		fr.SortGenomicSequences();
		fr.ReadGenomeData(genFile);
		fr.SearchGenomeSeq();
	}
	else{
		cout << "Invalid option" << "\n";
	}
	return 0;
}
