#ifndef FASTAreadset_LL_H // include guard
#define FASTAreadset_LL_H

#include <iostream>
#include <fstream>
#include <time.h> 
#include <math.h>

//This constant represents size of character array required to store string representing genomic sequence
#define NucleoLineSize 51

#define Million 1000000

#define All 36000000

using namespace std;

void PrintCurrentTime();
int strcmp(const char* s1, const char* s2);

//structure for holding lines from read set
struct Node{
	char line[NucleoLineSize];
	struct Node* next; // pointer to next node
};

class FASTAreadset_LL{
			
	public:
		//file stream variable
		ifstream file;
		
		//file path variable
		char* filePath;
		
		// for storing the lines read so far
		int linesRead;
		
		//pointer to start of linked list for dataset
		Node* head;
		
		//pointer to array of sorted records
		char** sortedRecords;
		
		//pointer to start of linked list for genomic sequence
		Node* genHead;
		
		//Default Constructor
		FASTAreadset_LL(){
			head = NULL;
			genHead = NULL;
		}
		
		//Custom constructor taking file path argument
		FASTAreadset_LL(char* path){
			filePath = path;
			head = NULL;
			genHead = NULL;
		}	
		
		//Method to read file
		//filePath contains the path to actual file
		//lines contains the number of lines to be read from file
		void ReadFile(char* filePath, int lines){
			linesRead = lines;
			
			if(file.is_open()){
				file.close();
			}
			
			file.open(filePath);
			
			string line;
			int count = 0;
			Node* current = NULL; //keeping track of current node
			
			while(lines > 0){
				// read the string representing header data and ignore this
				getline(file, line);
				
				//read the string representing genomic sequence
				getline(file, line);
				
				Node* record = new Node;
			    //strcpy(record -> line, line.c_str());
			    for(int k = 0; k < 50; k++){
	    		 	(record -> line)[k] = (line.c_str())[k];
				}
	    	    (record -> line)[50] = '\0';

			    record -> next = NULL;
				
				if(current != NULL){
					current -> next = record;
				}
				
				current = record;
				
				//if it's the first node then pointing head to it
				if(count == 0){
					head = record;
				}
				
				count++;
				lines--;
				
			}
			
			file.close();
		}
		
		//This is an overload method that reads n number of lines from file at file path used when using custom constructor
		void ReadFile(int lines){
			ReadFile(filePath, lines);
		}
		
		//Method to print genomic sequences read so far
		void printNucleoSet(){
			Node* temp; //pointer to traverse the list
			temp = head;
			
			while(temp != NULL){
				cout << temp -> line << "\n";
				temp = temp -> next;
			}
		}
		
		//Utility function used by quick sort
		void swap(char *v[], int i, int j){
			char* temp;
			temp = v[i];
			v[i] = v[j];
			v[j] = temp;	
		}
		
		//Utility function for sorting strings
		void QuickSort(char* v[], int left, int right){
			int i;
			int last;
			
			if(left >= right){
				return;
			}
			swap(v, left, (left + right)/2);
			last = left;
			
			for(i = left + 1; i <= right; i++){
				if(strcmp(v[i], v[left]) < 0){
					swap(v, ++last, i);
				}
			}
			swap(v, left, last);
			QuickSort(v, left, last - 1);
			QuickSort(v, last + 1, right);
		}
		
		//Method to sort genomic sequences
		void SortGenomicSequences(){
			
			cout << "Sorting started at: ";
			PrintCurrentTime();
						
		    sortedRecords = new char*[linesRead];
			
			int index = 0;
			Node* current = head;
			while(current != NULL){
				sortedRecords[index] = current -> line;
				index++;
				current = current -> next;
			}
			
			QuickSort(sortedRecords, 0, linesRead - 1);
			
			//copying the string represented by sorted array to new array
						
			cout << "Sorted the dataset at: ";
			PrintCurrentTime();
			
			//avoiding memory leakage
			
		}

		//Method to perform binary search
		int BinarySearch(char record[]){
			int start = 0;
			int end = linesRead - 1;
			while(start < end){
				int half = (start + end) / 2;
				if(strcmp(sortedRecords[half], record) > 0){
					end = half - 1;
				}
				else if(strcmp(sortedRecords[half], record) < 0){
					start = half + 1;
				}
				else{
					return half;
				}
			}
			
			return -1;
		}

		//Method to search a record in record set
		void PerformSearch(){
			char seq1[] = "CTAGGTACATCCACACACAGCAGCGCATTATGTATTTATTGGATTTATTT";
			char seq2[] = "GCGCGATCAGCTTCGCGCGCACCGCGAGCGCCGATTGCACGAAATGGCGC";
			char seq3[] = "CGATGATCAGGGGCGTTGCGTAATAGAAACTGCGAAGCCGCTCTATCGCC";
			char seq4[] = "CGTTGGGAGTGCTTGGTTTAGCGCAAATGAGTTTTCGAGGCTATCAAAAA";
			char seq5[] = "ACTGTAGAAGAAAAAAGTGAGGCTGCTCTTTTACAAGAAAAAGTNNNNNN";
			int index;
			
			cout << "Performing search for sequence 1 " << seq1 << "\n";
			index = BinarySearch(seq1);
			if(index > -1)
				cout << "Found at position " << index + 1 << " in sorted dataset" << "\n";
			else
				cout << "Not found" << "\n";
			
			cout << "Performing search for sequence 2 " << seq1 <<  "\n";
			index = BinarySearch(seq2);
			if(index > -1)
				cout << "Found at position " << index + 1 << " in sorted dataset" << "\n";
			else
				cout << "Not found" << "\n";
				
			cout << "Performing search for sequence 3 " << seq1 <<  "\n";
			index = BinarySearch(seq3);
			if(index > -1)
				cout << "Found at position " << index + 1 << " in sorted dataset" << "\n";
			else
				cout << "Not found" << "\n";
				
			cout << "Performing search for sequence 4 " << seq1 << "\n";
			index = BinarySearch(seq4);
			if(index > -1)
				cout << "Found at position " << index + 1 << " in sorted dataset" << "\n";
			else
				cout << "Not found" << "\n";
				
			cout << "Performing search for sequence 5 " << seq1 <<  "\n";
			index = BinarySearch(seq5);
			if(index > -1)
				cout << "Found at position " << index + 1 << " in sorted dataset" << "\n";
			else
				cout << "Not found" << "\n";
		}
		
		//Method to initialize array with all 36 million records 
		void InitializeAll(){
			
			cout << "Initialization started at: ";
			PrintCurrentTime();
			
			ReadFile(All);
			
			cout << "Successfully initialized with " << All << " records at: ";
			PrintCurrentTime(); 
		}
		
		//Method to read genome data
		void ReadGenomeData(char* filePath){
			ifstream file;
			file.open(filePath);
			
			cout << "Initializing genome data started at:";
			PrintCurrentTime();
			
			char temp[50];
			char c = '\0';
			int count = 0;
			int records = 0;
			Node* current;
			
			//skipping the first line
			while(c != '\n'){
				file.get(c);	
			}
			
  			while (file.get(c)){
  				if(c == 'A' || c == 'C' || c == 'G' || c == 'T' || c == 'N'){
  					temp[count] = c;
  					count++;
  					if(count == 50){
  						count = 49;
  						records++;
  						
  						Node* record = new Node;
  						for(int k = 0; k < 50; k++){
			    			(record -> line)[k] = temp[k];
						}
			    		(record -> line)[50] = '\0';

			    		record -> next = NULL;
			    		
			    		if(records == 1){
			    			genHead = record;
						}
						else{
							current -> next = record;
						}
						current = record;
					}
					if(genHead != NULL){
						ReArrange(temp, 50);
					}
				}  
			}         
			file.close();
			
			cout << "Successfully initialized with " << records << " records of 50 mers at:";
			PrintCurrentTime();
		}
		
		void ReArrange(char array[], int size){
			for(int i = 1; i < size; i++){
				array[i - 1] = array[i];
			}
		}
		
		//Method to print 50mers genomic sequence
		void PrintGenomeData(){
			Node* current = genHead;
			while(current != NULL){
				cout << current -> line << "\n";
				current = current -> next;
			}
		}
		
		//Method to search genome sequences
		void SearchGenomeSeq(){
			
			cout << "Search for genomic sequences started at: ";
			PrintCurrentTime();
			
			Node* current = genHead;
			int count = 0;
			int total = 0;
			while(current != NULL){
				count++;
				int index = BinarySearch(current -> line);
				if(index > -1)
					total++;
				current = current -> next;
			}
			
			cout << "Search ended at: ";
			PrintCurrentTime();
			
			cout << "Total " << total << " 50 mers sequences match were found" << "\n";
		}
		
		//Destructor
		~FASTAreadset_LL(){
			DeleteAllocation();
		}
		
		//Method for deleting memory used by arrays
		void DeleteAllocation(){
			cout << " De allocation started at: ";
			PrintCurrentTime();
			
			if(head != NULL)
				IterativeDelete(head);
		
			if(genHead != NULL){
				IterativeDelete(genHead);
			}
						
			cout << "Successfully de-allocated the memory used for storing records at: ";	
			PrintCurrentTime();		
		}

		void RecursiveDelete(Node* record){
			if(record != NULL){
				RecursiveDelete(record -> next);
				delete[] record;
			}
		}

		void IterativeDelete(Node* record){
			while(record != NULL){
				delete[] record;
				record = record -> next;
			}
		}
		
		//Copy Constructor performing deep copy
		FASTAreadset_LL(const FASTAreadset_LL &obj) {
			
			cout << "deep copy started at:";
			PrintCurrentTime();
			
   			//filePath = obj.filePath;
   			//file = obj.file;
   			head = NULL;
   			genHead = NULL;
   			
   			//Creating linked - list for fasta data set
   			Node* current;
   			int count = 0;
   			Node* temp = obj.head;
   			while(temp != NULL){
   				 Node* record = new Node;
				 //strcpy(record -> line, temp -> line);
				 for(int k = 0; k < 50; k++){
	    			(record -> line)[k] = (temp -> line)[k];
				 }
	    		 (record -> line)[50] = '\0';
				 record -> next = NULL;
				 
				 if(count == 0){
				 	head = record;
				 }
				 else{
				 	current -> next = record;
				 }
				 current = record;
				 temp = temp -> next;   	
				 count++;
			}
			
			count = 0;
			temp = obj.genHead;
			while(temp != NULL){
   				 Node* record = new Node;
				 //strcpy(record -> line, temp -> line);
				 for(int k = 0; k < 50; k++){
	    		 	(record -> line)[k] = (temp -> line)[k];
				 }
	    		 (record -> line)[50] = '\0';
				 record -> next = NULL;
				 record -> next = NULL;
				 
				 if(count == 0){
				 	genHead = record;
				 }
				 else{
				 	current -> next = record;
				 }
				 current = record;
				 temp = temp -> next;   	
				 count++;
			}
			
			cout << "deep copy completed at:";
			PrintCurrentTime();		
		}
};

void PrintCurrentTime(){
			time_t rawtime;
  			time(&rawtime);
  			tm *ltm = localtime(&rawtime);
			
			cout << ltm->tm_hour << ":";
   			cout << ltm->tm_min << ":";
   			cout << ltm->tm_sec << "\n";
		}
		
int strcmp(const char* string1, const char* string2)
{
    while(*string1 && (*string1==*string2)){
    	string1++;
		string2++;
	}
        
    return *(const unsigned char*)string1-*(const unsigned char*)string2;
}

#endif
