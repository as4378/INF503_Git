Modules needed for the code:

1. Python 3
2. I have also included the fasta format sequence for DENV2 in a file named "fragments.txt" which should be present in
   same directory as the python script file (Solutions.py).

Following commands are needed to execute different parts of the problem on monsoon:

python {name of python script file} {filename for fasta format sequence of DENV2} {part number}

1. For solving question 1 part A use: python Solutions.py fragments.txt A 
2. For solving question 1 part B use: python Solutions.py fragments.txt B
3. For solving question 2 part A use: python Solutions.py fragments.txt C 
4. For solving question 2 part B use: python Solutions.py fragments.txt D 
5. For solving question 2 part C use: python Solutions.py fragments.txt E 
